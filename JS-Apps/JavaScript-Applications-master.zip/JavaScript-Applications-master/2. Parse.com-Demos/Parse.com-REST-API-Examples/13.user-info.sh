curl -X GET \
  -H "X-Parse-Application-Id: TWvkNXvWKe6GixlxZ44tv8pwacMJMwleMuG2oIT2" \
  -H "X-Parse-REST-API-Key: vIaiOnNJTeV4ZnqSHrocG4jlCP00iJd24NywZkM9" \
  -H "X-Parse-Session-Token: yQtztxp1DITdTmNWdxKidqXQn" \
  https://api.parse.com/1/users/me
