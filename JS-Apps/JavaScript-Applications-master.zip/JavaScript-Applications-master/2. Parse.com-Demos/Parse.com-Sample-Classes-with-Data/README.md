Parse.com - Sample Classes and Data
===================================

You can import the JSON data into "Question" and "Answer" classes in your Parse application.
