public class _03_Print_Hometown {
	public static void main(String[] args) {
		System.out.println("My hometown is Sofia, Bulgaria");
	}
}
