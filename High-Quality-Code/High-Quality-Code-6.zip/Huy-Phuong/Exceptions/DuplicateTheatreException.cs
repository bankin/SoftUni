﻿using System;

namespace TheatresManagement.Exceptions
{
    internal class DuplicateTheatreException : Exception
    {
        public DuplicateTheatreException(string msg)
            : base(msg)
        {
        }
    }
}
