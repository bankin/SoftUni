﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using TheatresManagement.Interfaces;

namespace TheatresManagement
{
    static class ExecuteCommand
    {
        private static readonly IPerformanceDatabase TheatreDatabase = new TheatreDatabase();

        internal static string AddTheatreCommand(string theatreName)
        {
            TheatreDatabase.AddTheatre(theatreName);
            return "Theatre added";
        }

        //Bottleneck: The ListTheatres method gives you the theater names no need to do anything else.
        public static string PrintAllTheatresCommand()
        {
            var theatres = TheatreDatabase.ListTheatres();
            if (theatres.Any())
            {
                return String.Join(", ", theatres);
            }

            return "No theatres";
        }

        public static void AddPerformance(string theatreName, string performanceName, DateTime startDateTime, TimeSpan duration, decimal price)
        {
            TheatreDatabase.AddPerformance(theatreName, performanceName, startDateTime, duration, price);
        }

        //Bottleneck
        public static string PrintAllPerformancesCommand()
        {
            var performances = TheatreDatabase.ListAllPerformances().ToList();
            var resultStringBuilder = new StringBuilder();
            if (performances.Any())
            {
                for (int i = 0; i < performances.Count; i++)
                {
                    resultStringBuilder.Append(performances[i]);
                    if (i < performances.Count - 1)
                    {
                        resultStringBuilder.Append(", ");
                    }
                    //string startDateTime = performances[i].StartDateTime.ToString("dd.MM.yyyy HH:mm");
                    //resultStringBuilder.AppendFormat("({0}, {1}, {2})", performances[i].PerformanceName, performances[i].TheatreName, startDateTime);
                    //result = resultStringBuilder + "";
                }
                return resultStringBuilder.ToString();
            }

            return "No performances";
        }

        public static string PrintPerformances(string theatre)
        {
            var performances = TheatreDatabase.ListPerformances(theatre).Select(p =>
            {
                string result1 = p.StartDateTime.ToString("dd.MM.yyyy HH:mm");
                return string.Format("({0}, {1})", p.PerformanceName, result1);
            }).ToList();

            return performances.Any() ? string.Join(", ", performances) : "No performances";
        }
    }
}