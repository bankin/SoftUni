﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using TheatresManagement.Interfaces;

namespace TheatresManagement
{
    static class ExecuteCommand
    {
        private static readonly IPerformanceDatabase TheatreDatabase = new TheatreDatabase();

        internal static string AddTheatreCommand(string theatreName)
        {
            TheatreDatabase.AddTheatre(theatreName);
            return "Theatre added";
        }

        public static string PrintAllTheatresCommand()
        {
            var theatresCount = TheatreDatabase.ListTheatres().Count();
            if (theatresCount > 0)
            {
                var resultTheatres = new LinkedList<string>();
                for (int i = 0; i < theatresCount; i++)
                {
                    TheatreDatabase.ListTheatres().Skip(i).ToList().ForEach(
                        t => resultTheatres.AddLast(t));
                    foreach (var t in TheatreDatabase.ListTheatres().Skip(i + 1))
                    {
                        resultTheatres.Remove(t);
                    }
                }
                return String.Join(", ", resultTheatres);
            }

            return "No theatres";
        }

        public static void AddPerformance(string theatreName, string performanceName, DateTime startDateTime, TimeSpan duration, decimal price)
        {
            TheatreDatabase.AddPerformance(theatreName, performanceName, startDateTime, duration, price);
        }

        public static string PrintAllPerformancesCommand()
        {
            var performances = TheatreDatabase.ListAllPerformances().ToList();
            var result = String.Empty;
            if (performances.Any())
            {
                for (int i = 0; i < performances.Count; i++)
                {
                    var sb = new StringBuilder();
                    sb.Append(result);
                    if (i > 0)
                    {
                        sb.Append(", ");
                    }
                    string result1 = performances[i].StartDateTime.ToString("dd.MM.yyyy HH:mm");
                    sb.AppendFormat("({0}, {1}, {2})", performances[i].PerformanceName, performances[i].TheatreName, result1);
                    result = sb + "";
                }
                return result;
            }

            return "No performances";
        }

        public static IEnumerable<string> PrintPerformances(string theatre)
        {
            return TheatreDatabase.ListPerformances(theatre).Select(p =>
            {
                string result1 = p.StartDateTime.ToString("dd.MM.yyyy HH:mm");
                return string.Format("({0}, {1})", p.PerformanceName, result1);
            }).ToList();
        }
    }
}
