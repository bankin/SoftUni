﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using TheatresManagement.Interfaces;

namespace TheatresManagement
{
    internal class MainClass
    {
        protected static void Main()
        {
            while (true)
            {
                string commandLine = Console.ReadLine();
                if (commandLine == null)
                {
                    return;
                }

                if (commandLine != string.Empty)
                {
                    string command = commandLine.Split('(')[0];
                    string[] commandArgs = commandLine.Split(new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries); ;
                    string commandResult;
                    
                    try
                    {
                        switch (command)
                        {
                            case "AddTheatre":                                
                                commandResult = ExecuteCommand.AddTheatreCommand(commandArgs[1].Trim());
                                break;
                            case "PrintAllTheatres":
                                commandResult = ExecuteCommand.PrintAllTheatresCommand();
                                break;
                            case "AddPerformance":                                
                                string[] commandArgsTrim = commandArgs.Skip(1).Select(p => p.Trim()).ToArray();

                                string theatreName = commandArgsTrim[0];
                                string performanceTitle = commandArgsTrim[1];
                                DateTime startDateTime = DateTime.ParseExact(commandArgsTrim[2], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);
                                TimeSpan duration = TimeSpan.Parse(commandArgsTrim[3]);
                                decimal price = decimal.Parse(commandArgsTrim[4], NumberStyles.Float);

                                ExecuteCommand.AddPerformance(theatreName, performanceTitle, startDateTime, duration, price);
                                commandResult = "Performance added";
                                break;
                            case "PrintAllPerformances":
                                commandResult = ExecuteCommand.PrintAllPerformancesCommand();
                                break;
                            case "PrintPerformances":                                
                                string theatre = commandArgs[1].Trim();

                                var performances = ExecuteCommand.PrintPerformances(theatre);
                                if (performances.Any())
                                {
                                    commandResult = string.Join(", ", performances);
                                }
                                else
                                {
                                    commandResult = "No performances";
                                }
                                break;
                            default:
                                commandResult = "Invalid command!";
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        commandResult = "Error: " + ex.Message;
                    }

                    Console.WriteLine(commandResult);
                }
            }
        }
    }   
}
