﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Huy_Phuong
{
    using System;
    using System.Threading;

    // Do not modify the interface members
    // Moving the interface to separate namespace is allowed
    // Adding XML documentation is allowed
    // TODO: document this interface definition
    internal interface IPerformanceDatabase
    {
        // TODO: document this method, its parameters, return value, exceptions, etc.
        void AddTheatre(string theatre);

        // TODO: document this method, its parameters, return value, exceptions, etc.
        IEnumerable<string> ListTheatres();

        // TODO: document this method, its parameters, return value, exceptions, etc.
        void AddPerformance(string theatreName, string performanceTitle, DateTime startDateTime, TimeSpan duration,
            decimal price);

        // TODO: document this method, its parameters, return value, exceptions, etc.
        IEnumerable<BuoiDien> ListAllPerformances();

        // TODO: document this method, its parameters, return value, exceptions, etc.
        IEnumerable<BuoiDien> ListPerformances(string theatreName);
    }


    internal class TheatreNotFoundException : Exception
    {
        public TheatreNotFoundException(string msg)
            : base(msg)
        {
        }
    }

    internal partial class NhàHát
    {
        public static IPerformanceDatabase universal = new BuổIDiễNDatabase();

        protected static void Main()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("vi-VN");
            while (true)
            {
                string commandLine = Console.ReadLine();
                if (commandLine == null)
                {
                    return;
                }

                if (commandLine != string.Empty)
                {
                    string[] commandLineArgs = commandLine.Split('(');
                    string command = commandLineArgs[0];
                    string commandResult;
                    
                    try
                    {
                        switch (command)
                        {
                            case "AddTheatre":
                                // WTF !? Bottleneck maybe
                                string[] commandParts1 = commandLine.Split(new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                string[] commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();
                                string[] commandParams = commandParams1;
                                commandResult = Class1.ExecuteAddTheatreCommand(commandParams);
                                break;
                            case "PrintAllTheatres":
                                commandResult = Class1.ExecutePrintAllTheatresCommand();
                                break;
                            case "AddPerformance":
                                // WTF !? Bottleneck maybe
                                commandParts1 = commandLine.Split(new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();

                                commandParams = commandParams1;
                                string theatreName = commandParams[0];
                                string performanceTitle = commandParams[1];
                                DateTime result = DateTime.ParseExact(commandParams[2], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);

                                DateTime startDateTime = result;
                                TimeSpan result2 = TimeSpan.Parse(commandParams[3]);
                                TimeSpan duration = result2;
                                decimal result3 = decimal.Parse(commandParams[4], NumberStyles.Float);
                                decimal price = result3;

                                NhàHát.universal.AddPerformance(theatreName, performanceTitle, startDateTime, duration, price);
                                commandResult = "Performance added";
                                break;
                            case "PrintAllPerformances":
                                commandResult = ExecutePrintAllPerformancesCommand();
                                break;
                            case "PrintPerformances":
                                commandLineArgs = commandLine.Split('(');
                                command = commandLineArgs[0];

                                commandParts1 = commandLine.Split( new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();

                                commandParams = commandParams1;
                                string theatre = commandParams[0];

                                var performances = universal.ListPerformances(theatre).Select(p => 
                                    {
                                        string result1 = p.Date.ToString("dd.MM.yyyy HH:mm");
                                        return string.Format("({0}, {1})", p.tr32, result1);
                                    }).ToList();
                                if (performances.Any())
                                {
                                    commandResult = string.Join(", ", performances);
                                }
                                else
                                {
                                    commandResult = "No performances";
                                }
                                break;
                            default:
                                commandResult = "Invalid command!";
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        commandResult = "Error: " + ex.Message;
                    }

                    Console.WriteLine(commandResult);
                }
            }
        }
    }


    public class TimeDurationOverlapException : Exception
    {
        public TimeDurationOverlapException(string msg)
            : base(msg)
        {
        }
    }

    public class BuoiDien : IComparable<BuoiDien>
    {
        public BuoiDien(string tr23, string tr32, DateTime date, TimeSpan duration, decimal gia)
        {
            this.tr23 = tr23;
            this.tr32 = tr32;
            this.Date = date;
            this.Duration = duration;
            this.gia = gia;
        }

        public string tr23 { get; protected internal set; }
        public string tr32 { get; private set; }
        public DateTime Date { get; set; }
        public TimeSpan Duration { get; private set; }
        protected internal decimal gia { get; protected set; }

        int IComparable<BuoiDien>.CompareTo(BuoiDien otherBuoiDien)
        {
            int tmp = this.Date.CompareTo(otherBuoiDien.Date);
            return tmp;
        }

        public override string ToString()
        {
            string result = string.Format("BuoiDien(Tr32: {0}; Tr23: {1}; date: {2}, duration: {3}, Gia: {4})",
                this.tr23,
                this.tr32,
                this.Date.ToString("dd.MM.yyyy HH:mm"), this.Duration.ToString("hh':'mm"), this.gia.ToString("f2"));
            return result;
        }
    }

    internal class BuổIDiễNDatabase : IPerformanceDatabase
    {
        private readonly SortedDictionary<string, SortedSet<BuoiDien>> sortedDictionaryStringSortedSetPerformance;

        public BuổIDiễNDatabase()
        {
            this.sortedDictionaryStringSortedSetPerformance = new SortedDictionary<string, SortedSet<BuoiDien>>();   
        }
        
        public void AddTheatre(string theatre)
        {
            if (this.sortedDictionaryStringSortedSetPerformance.ContainsKey(theatre))
            {
                throw new DuplicateTheatreException("Duplicate theatre");
            }

            this.sortedDictionaryStringSortedSetPerformance[theatre] = new SortedSet<BuoiDien>();
        }


        private class DuplicateTheatreException : Exception
        {
            public DuplicateTheatreException(string msg)
                : base(msg)
            {
            }
        }


        public IEnumerable<string> ListTheatres()
        {
            var t2 = this.sortedDictionaryStringSortedSetPerformance.Keys;
            return t2;
        }

        void IPerformanceDatabase.AddPerformance(string tt,
            string pp, DateTime s2, TimeSpan thoiGian, decimal gia)
        {
            if (!this.sortedDictionaryStringSortedSetPerformance.ContainsKey(tt))
            {
                throw new TheatreNotFoundException("Theatre does not exist");
            }

            var ps = this.sortedDictionaryStringSortedSetPerformance[tt];


            var e2 = s2 + thoiGian;
            if (kiemTra(ps, s2, e2))
            {
                throw new TimeDurationOverlapException("Time/duration overlap");
            }

            var p = new BuoiDien(tt, pp, s2, thoiGian, gia);
            ps.Add(p);
        }

        public IEnumerable<BuoiDien> ListAllPerformances()
        {
            var theatres = this.sortedDictionaryStringSortedSetPerformance.Keys;


            var result2 = new List<BuoiDien>();
            foreach (var t in theatres)
            {
                var performances = this.sortedDictionaryStringSortedSetPerformance[t];
                result2.AddRange(performances);
            }

            return result2;
        }

        IEnumerable<BuoiDien> IPerformanceDatabase.ListPerformances(string theatreName)
        {
            if (!this.sortedDictionaryStringSortedSetPerformance.ContainsKey(theatreName))
            {
                throw new TheatreNotFoundException("Theatre does not exist");
            }
            var asfd = this.sortedDictionaryStringSortedSetPerformance[theatreName];
            return asfd;
        }


        protected internal static bool kiemTra(IEnumerable<BuoiDien> performances, DateTime ss2, DateTime ee2)
        {
            foreach (var p in performances)
            {
                var ss = p.Date;

                var ee = p.Date + p.Duration;
                var check = (ss <= ss2 && ss2 <= ee) || (ss <= ee2 && ee2 <= ee) || (ss2 <= ss && ss <= ee2) || (ss2 <= ee && ee <= ee2);
                if (check)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
