﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Huy_Phuong
{
    internal class MainClass
    {
        public static IPerformanceDatabase universal = new TheatreDatabase();

        protected static void Main()
        {
            while (true)
            {
                string commandLine = Console.ReadLine();
                if (commandLine == null)
                {
                    return;
                }

                if (commandLine != string.Empty)
                {
                    string[] commandLineArgs = commandLine.Split('(');
                    string command = commandLineArgs[0];
                    string commandResult;
                    
                    try
                    {
                        switch (command)
                        {
                            case "AddTheatre":
                                // WTF !? Bottleneck maybe
                                string[] commandParts1 = commandLine.Split(new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                string[] commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();
                                string[] commandParams = commandParams1;
                                commandResult = Class1.ExecuteAddTheatreCommand(commandParams);
                                break;
                            case "PrintAllTheatres":
                                commandResult = Class1.ExecutePrintAllTheatresCommand();
                                break;
                            case "AddPerformance":
                                // WTF !? Bottleneck maybe
                                commandParts1 = commandLine.Split(new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();

                                commandParams = commandParams1;
                                string theatreName = commandParams[0];
                                string performanceTitle = commandParams[1];
                                DateTime result = DateTime.ParseExact(commandParams[2], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);

                                DateTime startDateTime = result;
                                TimeSpan result2 = TimeSpan.Parse(commandParams[3]);
                                TimeSpan duration = result2;
                                decimal result3 = decimal.Parse(commandParams[4], NumberStyles.Float);
                                decimal price = result3;

                                MainClass.universal.AddPerformance(theatreName, performanceTitle, startDateTime, duration, price);
                                commandResult = "Performance added";
                                break;
                            case "PrintAllPerformances":
                                commandResult = ExecutePrintAllPerformancesCommand();
                                break;
                            case "PrintPerformances":
                                commandLineArgs = commandLine.Split('(');
                                command = commandLineArgs[0];

                                commandParts1 = commandLine.Split( new[] { '(', ',', ')' }, StringSplitOptions.RemoveEmptyEntries);
                                commandParams1 = commandParts1.Skip(1).Select(p => p.Trim()).ToArray();

                                commandParams = commandParams1;
                                string theatre = commandParams[0];

                                var performances = universal.ListPerformances(theatre).Select(p => 
                                    {
                                        string result1 = p.Date.ToString("dd.MM.yyyy HH:mm");
                                        return string.Format("({0}, {1})", p.tr32, result1);
                                    }).ToList();
                                if (performances.Any())
                                {
                                    commandResult = string.Join(", ", performances);
                                }
                                else
                                {
                                    commandResult = "No performances";
                                }
                                break;
                            default:
                                commandResult = "Invalid command!";
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        commandResult = "Error: " + ex.Message;
                    }

                    Console.WriteLine(commandResult);
                }
            }
        }

        protected internal static string ExecutePrintAllPerformancesCommand()
        {
            var performances = MainClass.universal.ListAllPerformances().ToList();
            var result = String.Empty;
            if (performances.Any())
            {
                for (int i = 0; i < performances.Count; i++)
                {
                    var sb = new StringBuilder();
                    sb.Append(result);
                    if (i > 0)
                    {
                        sb.Append(", ");
                    }
                    string result1 = performances[i].Date.ToString("dd.MM.yyyy HH:mm");
                    sb.AppendFormat(
                        "({0}, {1}, {2})", performances[i].tr32, performances[i].tr23, result1);
                    result = sb + "";
                }
                return result;
            }

            return "No performances";
        }
    }   
}
