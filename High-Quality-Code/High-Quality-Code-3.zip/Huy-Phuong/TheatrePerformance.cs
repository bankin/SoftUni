﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatresManagement
{
    public class TheatrePerformace : IComparable<TheatrePerformace>
    {
        public TheatrePerformace(string theatreName, string performanceName, DateTime startDateTime, TimeSpan duration, decimal price)
        {
            this.TheatreName = theatreName;
            this.PerformanceName = performanceName;
            this.StartDateTime = startDateTime;
            this.Duration = duration;
            this.Price = price;
        }

        public string TheatreName { get; protected internal set; }
        public string PerformanceName { get; private set; }
        public DateTime StartDateTime { get; set; }
        public TimeSpan Duration { get; private set; }
        protected internal decimal Price { get; protected set; }

        int IComparable<TheatrePerformace>.CompareTo(TheatrePerformace otherTheatrePerformace)
        {
            return this.StartDateTime.CompareTo(otherTheatrePerformace.StartDateTime);
        }

        public override string ToString()
        {
            string result = string.Format("TheatrePerformace(Tr32: {0}; Tr23: {1}; startDateTime: {2}, duration: {3}, Gia: {4})",
                this.TheatreName,
                this.PerformanceName,
                this.StartDateTime.ToString("dd.MM.yyyy HH:mm"), this.Duration.ToString("hh':'mm"), this.Price.ToString("f2"));
            return result;
        }
    }
}
