﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using TheatresManagement.Interfaces;

namespace TheatresManagement
{
    static class ExecuteCommand
    {
        private static readonly IPerformanceDatabase TheatreDatabase = new TheatreDatabase();

        internal static string AddTheatreCommand(string theatreName)
        {
            TheatreDatabase.AddTheatre(theatreName);
            return "Theatre added";
        }

        public static string PrintAllTheatresCommand()
        {
            var theatresCount = TheatreDatabase.ListTheatres().Count();
            if (theatresCount > 0)
            {
                var resultTheatres = new LinkedList<string>();
                for (int i = 0; i < theatresCount; i++)
                {
                    TheatreDatabase.ListTheatres().Skip(i).ToList().ForEach(
                        t => resultTheatres.AddLast(t));
                    foreach (var t in TheatreDatabase.ListTheatres().Skip(i + 1))
                    {
                        resultTheatres.Remove(t);
                    }
                }
                return String.Join(", ", resultTheatres);
            }

            return "No theatres";
        }

        public static void AddPerformance(string theatreName, string performanceName, DateTime startDateTime, TimeSpan duration, decimal price)
        {
            TheatreDatabase.AddPerformance(theatreName, performanceName, startDateTime, duration, price);
        }
    }
}
