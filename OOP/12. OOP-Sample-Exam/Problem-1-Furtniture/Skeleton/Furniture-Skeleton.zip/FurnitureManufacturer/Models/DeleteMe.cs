﻿namespace FurnitureManufacturer.Models
{
    public class DeleteMe
    {
        // TODO: Write all needed classes by implementing the interfaces in this namespace. You may delete this class
    }
}
