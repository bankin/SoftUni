﻿namespace NightlifeEntertainment
{
    using System;
   
    public enum PerformanceType
    {
        Movie,
        Opera,
        Theatre,
        Sport,
        Concert
    }
}
