function removeWhiteSpace(str){
	return str.replace(/\s+/g, '');
}

console.log(removeWhiteSpace('But you were living in another world tryin\' to get your message through'));