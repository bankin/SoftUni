function reverse(str){
	return str.split("").reverse().join("");
}

console.log(reverse('sample'));
console.log(reverse('softUni'));
console.log(reverse('java script'));