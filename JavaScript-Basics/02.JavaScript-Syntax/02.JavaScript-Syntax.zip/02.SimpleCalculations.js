function roundNumber(value){
	console.log(Math.round(value));
	console.log(Math.floor(value));
}

roundNumber(22.7);
roundNumber(12.3);
roundNumber(58.7);