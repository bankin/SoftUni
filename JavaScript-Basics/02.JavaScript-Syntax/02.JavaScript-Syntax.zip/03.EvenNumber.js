function evenChecker(number){
	return number % 2 == 0;
}

console.log(evenChecker(3));
console.log(evenChecker(127));
console.log(evenChecker(588));