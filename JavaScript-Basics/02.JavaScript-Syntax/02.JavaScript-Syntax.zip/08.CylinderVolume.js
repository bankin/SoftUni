function calcVolume(radius, height){
	return Math.PI*radius*radius*height;
}

console.log(calcVolume(2, 4));
console.log(calcVolume(5, 8));
console.log(calcVolume(12, 3));