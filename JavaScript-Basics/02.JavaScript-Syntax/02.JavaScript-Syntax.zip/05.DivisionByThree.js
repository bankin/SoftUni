function divisionByThree(value){
	return value % 3 == 0 ? "The number is devided by 3 without reminder" : "The number is not devided by 3 without reminder";
}

console.log(divisionByThree(12));
console.log(divisionByThree(188));
console.log(divisionByThree(591));