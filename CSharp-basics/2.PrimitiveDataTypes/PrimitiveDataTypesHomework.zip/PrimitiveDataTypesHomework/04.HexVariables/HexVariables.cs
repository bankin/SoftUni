﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.HexVariables
{
    class HexVariables
    {
        static void Main(string[] args)
        {
            int hexVar = 0xfe;
            Console.WriteLine(hexVar);
        }
    }
}
