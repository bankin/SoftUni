﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12.BankAccountData
{
    class BankAccountData
    {
        static void Main(string[] args)
        {
            string firstName;
            string middleName;
            string lastName;
            double balance;
            string bankName;
            string IBAN;
            string[] cardNumbers = new string[3];

        }
    }
}
