﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.DeclareVariables
{
    class DecalreVariables
    {
        static void Main(string[] args)
        {
            ushort number1 = 52130;
            sbyte number2 = -115;
            int number3 = 4825932;
            byte number4 = 97;
            short number5 = -10000;
        }
    }
}
