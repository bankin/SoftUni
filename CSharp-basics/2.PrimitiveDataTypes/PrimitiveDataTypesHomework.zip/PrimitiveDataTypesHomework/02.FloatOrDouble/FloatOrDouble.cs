﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.FloatOrDouble
{
    class FloatOrDouble
    {
        static void Main(string[] args)
        {
            double number1 = 34.567839023;
            float number2 = 12.345f;
            double number3 = 8923.1234857;
            float number4 = 3456.091f;
        }
    }
}
